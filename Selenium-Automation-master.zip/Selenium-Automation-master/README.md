# Selenium-Project
Selenium Testing mini project for automated testing of web application
Selenium automated testing is done on auction webapp. Selenium works on firefox driver and tests built test cases. 
TestNG is used to generate test report for selenium.
